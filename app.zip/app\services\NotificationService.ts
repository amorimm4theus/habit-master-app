import * as Notifications from 'expo-notifications';
// import * as Device from 'expo-device';
// import { Platform } from 'react-native';

class NotificationService {
  async scheduleDailyNotifications(hours: number[]) {
    const permission = await Notifications.requestPermissionsAsync();
    if (!permission.granted) {
      console.warn('Permissão para notificações negada.');
      return;
    }

   /*  if (!Device.isDevice) {
      console.warn('As notificações só funcionam em dispositivos físicos.');
      return;
    } */

    for (const hour of hours) {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Hora de beber água!',
          body: 'Não se esqueça de se hidratar!',
          sound: true,
        },
        trigger: {
          hour: hour,
          minute: 0,
          repeats: true,
        },
      });
    }

    console.log('Notificações agendadas.');
  }
}

export default new NotificationService();
